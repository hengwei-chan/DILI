
close all;
clear;
clc;
format compact;

load "input data";

[train_scale,test_scale_x,ps] = scaleForSVM(train_data,test_data_x,0,1);
%%[train_scale,ps] = mapminmax(train_data,0,1);
%%[test_scale_x,ps] = mapminmax(test_data_x,0,1);
%%[predict_drug_scale,ps] = mapminmax(predict_drug,0,1);

[train_pca,test_pca] = pcaForSVM(train_scale,test_scale_x,95);

pso_option.c1 = 1.5;
pso_option.c2 = 1.7;
pso_option.maxgen = 100;
pso_option.sizepop = 20;
pso_option.k = 0.6;
pso_option.wV = 1;
pso_option.wP = 1;
pso_option.v = 5;
pso_option.popcmax = 100;
pso_option.popcmin = 0.1;
pso_option.popgmax = 100;
pso_option.popgmin = 0.1;
[bestacc,bestc,bestg]=psoSVMcgForClass(train_label,train_pca,pso_option);
ga_option.maxgen = 100;
ga_option.sizepop = 20;
ga_option.cbound = [0,100];
ga_option.gbound = [0,100];
ga_option.v = 10;
ga_option.ggap = 0.9;
[bestacc,bestc,bestg]=gaSVMcgForClass(train_label,train_pca,ga_option);
[bestacc,bestc,bestg]=SVMcgForClass(train_label,train_pca,-10,10,-10,10,5,0.5,0.5,4.5);
bestc
bestg

model = svmtrain(train_label,train_pca, '-s 1 -t 2 -c 256 -g 0.0078 ');

[predict_label,accuracy,decision_values] = svmpredict(test_label_x,test_pca, model);

% test for VF.m
[score,str] = VF(test_label_x,predict_label,1)
[score,str] = VF(test_label_x,predict_label,2)
[score,str] = VF(test_label_x,predict_label,3)
[score,str] = VF(test_label_x,predict_label,4)



figure;
hold on;
plot(test_label_x,'o');
plot(predict_label,'r*');
xlabel('Test Sample','FontSize',12);
ylabel('Category label','FontSize',12);
legend('The classification of actual test-set','The classification of predict test-set');
title('The actual classification and prediction of the test set of Chemicals','FontSize',12);
grid on;


AUC(predict_label,test_label_x)

